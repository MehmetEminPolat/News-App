import * as React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity,Platform,FlatList,ScrollView,Button,Linking} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';


export default class Detail extends React.Component {
  
   static navigationOptions = {
     headerTintColor: '#fff',
     headerTitleStyle: {
     fontWeight: 'bold',
    },
     headerStyle: {
      backgroundColor: '#3452eb',
    },
     title:"News"};
   
  

  render() {
    const item=this.props.navigation.getParam("item",null);
    return (

      <View style={styles.container}>
    
        <ScrollView>
       <Text style={styles.title2}> {item.name}</Text>
<Image style={{width:'100%',height:300,alignSelf:'center'}} source ={{uri:item.urlToImage}}/>
       <Text style={styles.title}> {item.title}</Text>
       <Text style={styles.title}> {item.description}</Text>
        </ScrollView>
        
      </View>

    );
  }
}
  

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding: 8,
  },
  title:{
    fontSize:12,
    textAlign:'center',
    borderWidth:1,
    borderRadius:5,
    marginTop:5,
    borderColor:'black',
    backgroundColor:'white',
  },

  title2:{
    fontSize:30,
    textAlign:'center',
    marginBottom:10,
    fontFamily:'bold',
    

  },

 
  
  
});
