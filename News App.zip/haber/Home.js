import * as React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity,Platform,ScrollView} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';


export default class Home extends React.Component {

  static navigationOptions = {
     headerTintColor: '#fff',
     headerTitleStyle: {
     fontWeight: 'bold',
    },
     headerStyle: {
      backgroundColor: '#3452eb',
    },
     title:"News"
   
  
  };

fncSendData=() =>{


const url="https://newsapi.org/v2/top-headlines"
const data={
  ref:"9b72058fa34d464cb1d1e0b1d2a439ca",
  face:"no",
}

axios.get(url,{params:data})
.then(res=>{

  const dt=res.data;
  
 
})
  
}

 fncOpenApp=()=>{
   
    this.props.navigation.navigate('business');
  }
  
  fncOpenApp2=()=>{
   
    this.props.navigation.navigate('entertainment');
  }
fncOpenApp3=()=>{
   
    this.props.navigation.navigate('technology');
  }

  fncOpenApp4=()=>{
   
    this.props.navigation.navigate('health');
  }
  fncOpenApp5=()=>{
   
    this.props.navigation.navigate('science');
  }

fncOpenApp6=()=>{
   
    this.props.navigation.navigate('sports');
  }

  render() {

    const {navigation}=this.props;
    const prKey=navigation.getParam("prKey","");
    return (


      <View style={styles.container}>


        <Image style={styles.imageStyle} source ={require('/News.jpg')}/>


         <ScrollView keyboardShouldPersistTaps={'always'} > 
        
      
         <TouchableOpacity onPress={this.fncOpenApp}>

         
        {
          <Text style={styles.btn}>Business</Text>
          
          }

        </TouchableOpacity>


        <TouchableOpacity onPress={this.fncOpenApp2}>

        {
          <Text style={styles.btn}>Entertainment</Text>
          
          }

        </TouchableOpacity>


        
        <TouchableOpacity onPress={this.fncOpenApp3}>

        {
          <Text style={styles.btn}>Technology</Text>
          
          }

        </TouchableOpacity>

         
        <TouchableOpacity onPress={this.fncOpenApp4}>

        {
          <Text style={styles.btn}>Health</Text>
          
          }

        </TouchableOpacity>


         <TouchableOpacity onPress={this.fncOpenApp5}>

        {
          <Text style={styles.btn}>Science</Text>
          
          }

        </TouchableOpacity>

        <TouchableOpacity onPress={this.fncOpenApp6}>

        {
          <Text style={styles.btn}>Sports</Text>
          
          }

        </TouchableOpacity>

        </ScrollView>

      
      </View>
    );

  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#edf0ef',
    padding: 8,
    
    
  },
 imageStyle: {
    height:'40%' ,
    width: '100%',
    padding:10,
    
   
  },
     btn: {
    width: '100%',
    padding: 10,
    fontsize: 30,
    textAlign: 'center',
    borderWidth: 1,
    borderColor: '#3a0fbd',
    backgroundColor: '#3452eb',
    color: 'white',
    borderRadius:10,
    marginTop:10,

  },

});
